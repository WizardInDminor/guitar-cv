# Guitar-to-CV Sequencer

A bare-metal STM32 capstone project that converts monophonic guitar input into real-time control voltage signals for Eurorack modular synthesizer systems.

---

## What This Project Does

The device accepts a guitar signal, detects pitch and note events in real time, and outputs:

- **1V/oct CV** — analog control voltage for driving modular oscillators
- **Gate** — note-on/note-off signal for triggering envelopes and other modules
- **Sequenced patterns** — recorded note events played back with tempo control

The system supports both quantized and unquantized operation, and provides a basic embedded UI for mode selection and parameter control.

---

## Core Hardware

| Component | Role | Status |
|---|---|---|
| STM32F407G-DISC1 | Development MCU board | ✅ Verified |
| STM32F405RG | Final target MCU | Not yet sourced |
| MCP4922 | 12-bit SPI DAC for CV output | On hand, unverified |
| SSD1306 OLED | Display | On hand, unverified |
| TL074 / TL072 | Op-amps for analog front end | On hand |
| TLE2426 | Virtual ground reference | On hand |

---

## Project Phases

| Phase | Description | Status |
|---|---|---|
| 1 | Platform Bring-Up | 🔄 In Progress |
| 2 | Audio and Detection Foundations | Not started |
| 3 | Musical Control Path | Not started |
| 4 | Product-Like Integration | Not started |
| 5 | Stretch Features | Not started |

---

## Session Log

| Session | Topic | Status |
|---|---|---|
| Session 01 | Toolchain, bare-metal blink, GDB debug | ✅ Complete |
| Session 02 | SPI bring-up, MCP4922 DAC | 🔄 Conceptual complete, bench pending |

---

## Key Design Constraints

- Bare-metal C — no HAL, no CubeIDE, no vendor abstraction
- Register-level peripheral configuration throughout
- Eurorack-compatible signal and power design direction
- Modular, testable firmware architecture

---

## Repository

`~/dev/school/stm32/guitar-cv`
